from setuptools import setup, find_packages

setup(
    name="rpi-web-shell",
    version="1.2.2",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "Flask>=2.0.0",
        "Flask-SocketIO>=5.0.0",
        "python-engineio>=4.0.0",
        "python-socketio>=5.0.0",
    ],
    entry_points={
        'console_scripts': [
            'rpi-web-shell=app:main',
        ],
    },
)
